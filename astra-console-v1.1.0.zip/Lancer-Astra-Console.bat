@echo off
start "Astra Console" "%~dp0index.html"
